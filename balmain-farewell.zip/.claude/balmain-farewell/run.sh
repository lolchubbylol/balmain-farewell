#!/bin/bash
cd "$(dirname "$0")"
npm install
npm run dev -- --port 3001